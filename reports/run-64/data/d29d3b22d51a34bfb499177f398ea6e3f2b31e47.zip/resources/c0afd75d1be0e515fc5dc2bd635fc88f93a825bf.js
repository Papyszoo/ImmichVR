/** <Typesetter>.init **/

troikaDefine(
function init(n){return function(e){return new Promise(t=>{n.typeset(e,t)})}}
)