/** <Typesetter>.getTransferables **/

troikaDefine(
function getTransferables(n){const e=[];for(let t in n)n[t]&&n[t].buffer&&e.push(n[t].buffer);return e}
)