/** <Typr Font Parser>.init **/

troikaDefine(
function init(n,e,t){const i=n(),r=e();return t(i,r)}
)