/** <Typesetter>.init **/

troikaDefine(
function init(n,e,t){return n(e,t())}
)